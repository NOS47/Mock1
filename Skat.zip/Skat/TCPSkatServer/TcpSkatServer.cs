﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Skat;

namespace TCPSkatServer
{
    class Program
    {
        
            static void Main(string[] args)
            {
                //Vi laver en ipadresse i det her tilfælde vores om til en instans.
                IPAddress ip = IPAddress.Parse("127.0.0.1");
                //TCP listener lytter efter respons fra en TCP CLIENT.
                TcpListener serverSocket = new TcpListener(ip, 7000);
                //Vi starter socket connection.
                serverSocket.Start();
                Console.WriteLine("Serveren er startet!");

            //Mens while true er sandt acceptere vores TCP server vores client. Samt 
                while (true)
                {
                    TcpClient connectionSocket = serverSocket.AcceptTcpClient();
                    Console.WriteLine("Serveren er aktiveret!");

                    BeregnAfgift afgift = new BeregnAfgift(connectionSocket);
                    Task.Factory.StartNew(() => afgift.DoIt());
                }
            }
        }
    }
