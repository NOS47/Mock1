﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using Skat;

namespace TCPSkatServer
{
    class BeregnAfgift
    {
        private TcpClient _connectionSocket;

        //Konstruktør 
        public BeregnAfgift(TcpClient connectionSocket)
        {
            _connectionSocket = connectionSocket;
        }

        public void DoIt()
        {
            //Et stream kan sende bytes afsted.
            Stream ns = _connectionSocket.GetStream();
            //StreamWriter konvertere strings om til bytes
            StreamReader sr = new StreamReader(ns);
            //StreamReader kan læse bytes og lave det om til string.
            StreamWriter sw = new StreamWriter(ns);
            //autoflush er sat til true så streamen er konstant indtil andet
            sw.AutoFlush = true;
            //Nyt objekt af klassen afgift, da vi skal kunne tilgå metoderne.
            Afgift afgift = new Afgift();

            //Mens vores while loop er true kan vi sende beskeder og svar til clienten. alt efter om klienten skriver bil eller elbil, samt reagere efter input fra clienten.
            while (true)
            {
                string message = sr.ReadLine();
                Console.WriteLine("Klient: " + message);

                if (message == "Bil" || message == "bil")
                {

                    string answer = "Indtast prisen på bilen";
                    sw.WriteLine(answer);

                    message = sr.ReadLine();
                    Console.WriteLine("Klient: " + message);
                   
                    int pris = Convert.ToInt32(message);

                    answer = "Afgiften på bilen er: " + afgift.BilAfgift(pris).ToString();
                    sw.WriteLine(answer);

                }
                else if (message == "Elbil" || message == "elbil")
                {

                    string answer = "Indtast prisen på bilen";
                    sw.WriteLine(answer);

                    message = sr.ReadLine();
                    Console.WriteLine("Klient: " + message);

                    int pris = Convert.ToInt32(message);

                    answer = "Afgift på bilen er: " + afgift.ElBilAfgift(pris).ToString();
                    sw.WriteLine(answer);

                }
                else
                {

                    string answer = "Indtast hvilken type bil du har";
                    sw.WriteLine(answer);

                }
            }
        }
    }
}
