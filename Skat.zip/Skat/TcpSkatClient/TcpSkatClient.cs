﻿using System;
using System.IO;
using System.Net.Sockets;

namespace TcpSkatClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vi laver en ny tcpclient objekt som har att ip adresse samt port nummer, så nu er server og client på et TCP netværk.
            TcpClient connectionSocket = new TcpClient("127.0.0.1", 7000);
            Console.WriteLine("Klienten er klar");

            //Et stream kan sende bytes afsted.
            Stream ns = connectionSocket.GetStream();
            //StreamWriter konvertere strings om til bytes
            StreamWriter sw = new StreamWriter(ns);
            //StreamReader kan læse bytes og lave det om til string.
            StreamReader sr = new StreamReader(ns);
            //autoflush er sat til true så streamen er konstant indtil andet.
            sw.AutoFlush = true;

            Console.WriteLine("Indtast bil eller elbil");
            //Vores true while loop sørger for at det er muligt at sende beskeder til serveren som tager i mod vores input.
            while (true)
            {
                string message = Console.ReadLine();
                sw.WriteLine(message);

                if (message == "Stop" || message == "stop") break;

                string answer = sr.ReadLine();
                Console.WriteLine("Server: " + answer);
            }

            Console.WriteLine("Tryk ENTER for at lukke dette vindue");
            Console.ReadKey();

            ns.Close();
            connectionSocket.Close();
        }
    }
}
