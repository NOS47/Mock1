﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Skat
{
    public class Afgift
    {
        public int BilAfgift(int pris)
        {
            //Vi definere en double
            double bilAfgift;
            //Først tjekker jeg om prisen er mindre end 0, og hvis den er kaster jeg en exception
            if (pris < 0)
            {
                throw new ArgumentException("Pris må ikke være mindre end 0");
            }

            
            //Vi tjekker om prisen er under eller i lig med 200000, hvis ja bruger jeg formlen bilafgift.
            //Til sidst udregner vi selve bilafgiften uden bilens pris, så vi har afgiften alene.
            if (pris <= 200000)
            {
                bilAfgift = pris * 0.85;
                
            }
            //Hvis prisen er større end 200000 så bruges formlen pris * 1.50 - 130000.
            //Til sidst udregner vi selve bilafgiftem udem bilens pris, så vi har afgiften alene.
            else
            {
                bilAfgift = (pris * 1.50) - 130000;
                
            }
            //Her konvertere jeg bilafgiften fra typen double til int
            int afgift = Convert.ToInt32(bilAfgift);
            //Metoden returnere afgift som heltal.
            return afgift;
        }

        public int ElBilAfgift(int pris)
        {
            //Vi definere en double.
            double elbilAgift;
            //Først tjekker jeg om prisen er mindre end 0, og hvis den er kaster jeg en exception
            if (pris < 0)
            {
                throw new ArgumentException("Pris må ikke være mindre end 0");
            }
            
            
            //Vi tjekker om prisen er under eller i lig med 200000, hvis ja bruger jeg formlen bilafgift.
            //Til sidst udregner vi selve bilafgiften uden bilens pris, så vi har afgiften alene.
            if (pris <= 200000)
            {
                elbilAgift = pris * 0.85;
                elbilAgift = elbilAgift * 0.20;
                
            }
            //Hvis prisen er større end 200000 så bruges formlen pris * 1.50 - 130000.
            //Til sidst udregner vi selve bilafgiftem udem bilens pris, så vi har afgiften alene.
            else
            {
                elbilAgift = (pris * 1.50) - 130000;
                elbilAgift = elbilAgift * 0.20;
                
            }
            //Her konvertere jeg bilafgiften fra typen double til int
            int afgift = Convert.ToInt32(elbilAgift);
            //Metoden returnere afgiften som heltal
            return afgift;
        }

    }
}
